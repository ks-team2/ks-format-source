package jp.co.f1.spring.bms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bmsspring05NakayamaApplicationTests {

	@Test
	void contextLoads() {
	}

}
