package jp.co.f1.spring.bms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bmsspring05NakayamaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Bmsspring05NakayamaApplication.class, args);
	}

}
