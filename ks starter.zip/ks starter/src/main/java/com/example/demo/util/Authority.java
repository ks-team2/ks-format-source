package com.example.demo.util;

public enum Authority {
	ADMIN,USER
}
