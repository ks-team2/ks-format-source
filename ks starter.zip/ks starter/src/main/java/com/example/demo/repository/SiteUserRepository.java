package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.SiteUser;

public interface SiteUserRepository extends JpaRepository<SiteUser,Long> {
//	Optional<SiteUser> findByUsername(String username);
	SiteUser findByUsername(String username);
	boolean existsByUsername(String username);
}
