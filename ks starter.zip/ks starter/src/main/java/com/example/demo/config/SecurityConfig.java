package com.example.demo.config;

import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.example.demo.util.Authority;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Configuration
@EnableWebSecurity
public class SecurityConfig{

//    private final UserDetailsService userDetailsService;
    
    @Bean
     PasswordEncoder passwordEncoder() {
    	//パスワードの暗号化用に、BCrypt（ビー・クリプト）を使用する
        return new BCryptPasswordEncoder();
    }
    
    
    
    
//    public void configure(WebSecurity web)throws Exception{
//    	//「/js/**」を追加
//    	web.ignoring().antMatchers(
//    			"/js/**","/css/**","/img/**","/webjars/**");
//    	}
//    
//    
//    protected void configure(HttpSecurity http)throws Exception{
//    	http.authorizeRequests()
//    	//「/register」を追加
//    	.antMatchers("/login","/error","/register").permitAll()
//    			//「/admin」は、ADMINユーザだけアクセス可能にします
//    	
//    	.antMatchers("/admin/**").hasRole(Authority.ADMIN.name())
//    	.anyRequest().authenticated()
//    	.and()
//    .formLogin()
//    	.loginPage("/login")
//    	.defaultSuccessUrl("/")
//    	.and()
//    .logout()
//    	.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
//    	.and()
//    	.rememberMe();
//    			
//    }
//    
//    protected void configure(AuthenticationManagerBuilder auth)throws Exception{
//    	//userDetailsServiceを使用して、DBからユーザを参照できるようにします
//    	auth.userDetailsService(userDetailsService)
//    	.passwordEncoder(passwordEncoder());
//    	
//    	}
//    }
//    
    
    

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.
        		//認証リクエストの設定
        		authorizeHttpRequests(auth -> auth
                // 「cssやjs、imagesなどの静的リソース」をアクセス可能にします
                .requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()
                // 「/register」と「/login」をアクセス可能にします
                .mvcMatchers("/register", "/login").permitAll()
                // 「/adminの配下」は、ADMINユーザだけアクセス可能にします
                .mvcMatchers("/admin/**").hasAuthority(Authority.ADMIN.name())
                //認証の必要があるように設定
                .anyRequest().authenticated()
            )
        		//フォームベースの認証の設定
            .formLogin(login -> login
                // ログイン時のURLを指定
                .loginPage("/login")
                // 認証後にリダイレクトする場所を指定
                .defaultSuccessUrl("/")
                .permitAll()
            )
            // ログアウトの設定
            .logout(logout -> logout
                // ログアウト時のURLを指定
                .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                .permitAll()
            )
            // Remember-Meの認証を許可します
            // これを設定すると、ブラウザを閉じて、
            // 再度開いた場合でも「ログインしたまま」にできます
            .rememberMe();
        return http.build();
    }

//    @Bean
//    public UserDetailsService userDetailsService() {
//        return username -> {
//            // ユーザ名を検索します（ユーザが存在しない場合は、例外をスローします）
//            var user = userRepository.findByUsername(username)
//                    .orElseThrow(() -> new UsernameNotFoundException(username + " not found"));
//
//            // ユーザ情報を返します
//            return new User(user.getUsername(), user.getPassword(),
//                    AuthorityUtils.createAuthorityList("ADMIN"));
//        };
    }

