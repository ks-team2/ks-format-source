package com.nts_ed.ks.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nts_ed.ks.dto.Employee;
import com.nts_ed.ks.param.LoginParam;
import com.nts_ed.ks.repository.EmployeeRepository;

@Controller
@RequestMapping
public class IndexController {
	
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
//	@GetMapping(path ="/a")
//	public @ResponseBody void index1() {
//		
	//This returns a JSON or XML with the users	
//	}
	@PostMapping(path="/login")
	public @ResponseBody List<Employee> index2(@RequestBody @Validated LoginParam param){
//	社員のチェックを行います。
		List<Employee> isExists = employeeRepository.checkEmployees(param.getId(),param.getPass());
		if(isExists.size()== 1) {
			System.out.println("成功");
			return isExists;
		}
	
			//return"";
			return null;
}
	@GetMapping(path="/")
	public String index() {
		
		//項目の初期化が書く必要になります。
		return "index";
	}
	
	}
	
