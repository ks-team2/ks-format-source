package com.nts_ed.ks.param;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class LoginParam {
	@NotBlank(message = "社員IDは必要です。")
	private String id;
	@NotBlank
	private String pass;
}
