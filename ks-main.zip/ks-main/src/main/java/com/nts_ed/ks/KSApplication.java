package com.nts_ed.ks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KSApplication {

	public static void main(String[] args) {
		SpringApplication.run(KSApplication.class, args);
	}

}
