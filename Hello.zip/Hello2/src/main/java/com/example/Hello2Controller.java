package com.example;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Hello2Controller {
	@GetMapping("/hello2")
	public String sayHello(@RequestParam("name")String name) {
		/*@RequestParamの名称と、バインドされる引数名が同じなら@RequestParamは省略可能
		 * ex)
		 *「 @RequestParam("name")String name,@RequestParam("age") int age」 =  「String neme,int age」
		http://localhost:8080/hello2?name=James  */
		return "Hello,World!"+"こんにちは"+name+"さん！";
	}
	
	
//	@GetMapping("/hello2")
//	public String sayHello(@RequestParam("name")String name,@RequestParam("age")int age) {
//		/*@RequestParamの名称と、バインドされる引数名が同じなら@RequestParamは省略可能
//		 * ex)
//		 *「 @RequestParam("name")String name,@RequestParam("age") int age」 =  「String neme,int age」
//		http://localhost:8080/hello2?name=james&&age=23   */
//		return "Hello,World!"+"こんにちは"+name+"さん！"+ age +"才なんですね！";
//	}

}
