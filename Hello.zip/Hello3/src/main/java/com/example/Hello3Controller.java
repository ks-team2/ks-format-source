package com.example;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Hello3Controller {
	//http://localhost:8080/hello3/James
	@GetMapping("/hello3/{name}")//引数に{}で囲まれた箇所はURLパスから値として取り出す部分を指定するもの「URIテンプレート変数」という。
	///hello3/Jamesと/hello3/{name}はパターン一致させる
	
	
	public String sayHello(@PathVariable("name")String name ) {//"name"はURIの{}変数と一致、nameはJamesとセット（バインド）
		return "Hello,World!"+"こんにちは"+name+"さん！";
	
	}  
	
	
	
//	@GetMapping("/hello3/{name}/{age}")//引数に{}で囲まれた箇所はURLパスから値として取り出す部分を指定するもの「URIテンプレート変数」という。
//	///hello3/Jamesと/hello3/{name}はパターン一致させる
//	
//	
//	public String sayHello(@PathVariable("name")String name ,@PathVariable("age")int age) {//"name"はURIの{}変数と一致、nameはJamesとセット（バインド）
//		return "Hello,World!"+"こんにちは"+name+"さん！"+ age +"才なんですね";
//		/*ex)
//		 * 複数の場合
//		 * @GetMapping("/hello3/{name}/{age}")
//		 * public String sayHello(@PathVariable("name")String name,@PathVariable("age")int age)
//		 http://localhost:8080/hello3/James/23  */
//	}  

}
