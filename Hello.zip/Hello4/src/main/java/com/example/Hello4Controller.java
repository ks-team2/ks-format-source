package com.example;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Hello4Controller {
	@PostMapping("/hello4")//@PostMappingはPOSTリクエストを処理するメソッドを意味する
	public String sayHello(@RequestParam("name")String name) {//formで入力された値はクエリ文字列列形式（パラメータ名＝パラメータ値）なので@RequestParamで受け取る
		return "Hello,world!"+"こんにちは"+name+"さん！";
	}

}
