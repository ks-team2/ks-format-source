package com.example;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Hello5Controller {//@RestControllerはテキスト用、@ControllerはThymeleafが処理したHTMLを返す用
	@GetMapping("/hello5")
	public ModelAndView sayHello(@RequestParam("name")String name,
			ModelAndView mv) {//Model Viewで使用するデータ View 次に表示する画面名
		mv.setViewName("hello");//View名を設定する
		mv.addObject("name",name);//Viewが使うデータを渡す 第2引数がViewに渡すデータ（オブジェクト）です　第1引数はその名前です　
		//HTMLのth:text="${name}"のnameは第1引数の方
		return mv;
	}
	
	//http://localhost:8080/hello5?name=james
}
