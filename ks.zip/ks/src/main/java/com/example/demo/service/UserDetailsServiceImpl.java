package com.example.demo.service;

import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo.repository.EmployeeRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class UserDetailsServiceImpl implements UserDetailsService{
	
	private final EmployeeRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException {
		// TODO 自動生成されたメソッド・スタブ
		
		 // SecurityConfig.javaの下部からコピーします
        // ユーザ名を検索します（ユーザが存在しない場合は、例外をスローします）
		var user=userRepository.findByUsername(username);
		
		if (username==null) {
			throw new UsernameNotFoundException(username+"not found");
			
		}
        // ユーザ情報を返します
        return new User(user.getUsername(),user.getPassword(),
                AuthorityUtils.createAuthorityList(user.getAuthority().name()));
		
	}
}

//	private UserDetails createUserDetails(SiteUser user) {
//		// TODO 自動生成されたメソッド・スタブ
//		
//		var grantedAuthorities = new HashSet<GrantedAuthority>();
//		grantedAuthorities.add(new SimpleGrantedAuthority("ROLE_"+user.getRole()));
//		
//		return new User(user.getUsername(),user.getPassword(),grantedAuthorities);
//	}
//
//}
