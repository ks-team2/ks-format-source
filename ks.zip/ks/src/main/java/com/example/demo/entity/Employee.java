package com.example.demo.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.example.demo.util.Authority;
import com.example.demo.validator.UniqueLogin;

import lombok.Data;

@Data
@Entity
@Table(name = "t_employee")
public class Employee{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
//  @NotBlank(message = "社員IDは存在しません。再度入力し直してください")
    private Long id;
    
    @Size(min = 2, max = 20)
    @UniqueLogin//自作バリデーションを追加
    private String username;
    
    @Size(min = 3, max = 255)
    @NotBlank(message = "パスワードが間違っています。再度入力しなおしてください。")
	private String password;
    
	private int gender;
	
	
	private int department;
	
	private String joining;
	private String age;
    
    @NotBlank
    @Email
	private String email;
    
	private String del_flg;
	private String create_user;
	private Date create_date;
	private Date update_date;
	private String update_user;

	
    private boolean admin;
    private Authority authority;
    
	public boolean isEmpty() {
		// TODO 自動生成されたメソッド・スタブ
		return false;
	}
    
    
	
}
