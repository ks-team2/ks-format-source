package com.example.demo.util;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class Type {
	public static final Map<Integer,String>GENDERS;
	static {
		Map<Integer, String>genders =new LinkedHashMap<>();
		genders.put(0,"選択しない");
		genders.put(1,"男性");
		genders.put(2,"女性");
		genders.put(3,"その他");
		GENDERS = Collections.unmodifiableMap(genders);
	}
	
	public static final Map<Integer, String>DEPARTMENTS;
	static {
		Map<Integer, String>departments = new LinkedHashMap<>();
		departments.put(0,"選択しない");
		departments.put(1,"開発部");
		departments.put(2,"総務部");
		departments.put(3,"経理部");
		departments.put(4,"人事部");
		departments.put(5,"その他");
		DEPARTMENTS = Collections.unmodifiableMap(departments);
		
	}
	
//	public static final Map<Integer, String>STATUSES;
//	static {
//		Map<Integer, String>statuses = new LinkedHashMap<>();
//		statuses.put(0,"選択しない");
//		statuses.put(1,"出勤");
//		statuses.put(2,"有給休暇");
//		statuses.put(3,"特別休暇");
//		statuses.put(4,"欠勤");
//		STATUSES = Collections.unmodifiableMap(statuses);
//		
//	}
}
