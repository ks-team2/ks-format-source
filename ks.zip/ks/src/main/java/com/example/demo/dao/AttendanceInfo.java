package com.example.demo.dao;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.Data;


//勤怠登録するファイル
@Data
@Entity
@Table(name = "t_attendance")
public class AttendanceInfo {
//	@GeneratedValue(strategy = GenerationType.IDENTITY)

//	@ManyToOne
	private String attendance_id;
	@Column(length =10)
	@Id
	private String  attendance_date;
	@NotBlank(message = "作業開始時間は必要です。")
	private String start_time;
	@NotBlank(message = "作業終了時間は必要です。")
	private String end_time;
	private String rest_hours;
	private String working_time;//
	private String overtime_hours;//
	private String absence_hours;
	private String status_id;
	
	private String remarks;
	
	private String del_flg;
	private String comment;//管理者の備考
	private Date create_date;
	private String create_user;
	private Date update_date;
	private String update_user;
	
}
