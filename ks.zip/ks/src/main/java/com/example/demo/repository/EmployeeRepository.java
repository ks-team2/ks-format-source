package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee,Long> {
//	Optional<SiteUser> findByUsername(String username);
	Employee findByUsername(String username);
	boolean existsByUsername(String username);
	
	
	
}
