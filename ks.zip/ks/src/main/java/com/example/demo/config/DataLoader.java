package com.example.demo.config;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.util.Authority;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class DataLoader implements ApplicationRunner {

    private final PasswordEncoder passwordEncoder;
    private final EmployeeRepository userRepository;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        // "admin"ユーザを用意します
        var user = new Employee();
        user.setUsername("admin");
        user.setPassword(passwordEncoder.encode("password"));
        user.setGender(0);
        user.setDepartment(0);
        user.setJoining(null);
        user.setAge("30");
        user.setEmail("admin@example.com");
        user.setDel_flg("1");
        user.setCreate_user("田中太郎");
        user.setCreate_date(null);
        user.setUpdate_date(null);
        user.setUpdate_user("田中太郎");
        user.setAdmin(true);
        user.setAuthority(Authority.ADMIN);
        
     // ユーザが存在しない場合、登録します
        
        if (userRepository.findByUsername(user.getUsername()).isEmpty()) {
        userRepository.save(user);
    }
  }
}
