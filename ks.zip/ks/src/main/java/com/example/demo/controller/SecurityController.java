package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.dao.AttendanceInfo;
import com.example.demo.dao.AttendanceRegister;
import com.example.demo.entity.Attendance;
import com.example.demo.entity.Employee;
import com.example.demo.repository.AttendanceRepository;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.util.Authority;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
public class SecurityController {

	
	@Autowired
	private final EmployeeRepository t_employee;
	
	@Autowired
	private final AttendanceRepository t_attendance;
	
	@Autowired
	private final PasswordEncoder passwordEncoder;
	
	
    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/")
    public String showList(Authentication loginUser, Model model) {
        model.addAttribute("username", loginUser.getName());
        model.addAttribute("authority", loginUser.getAuthorities());
        return "user";
    }
    
    
    
    
    //社員としての機能
    
    //1年間勤怠情報
    @GetMapping("/login/attendance")
    public String attendanceYear(Model model) {
    	
    	model.addAttribute("attendanceinfo",t_attendance.findAll());
		return "attendanceYear";
    }
    
    
    
    
    
    
    //1ヶ月勤怠情報
    @GetMapping("/login/attendance/month")
    public ModelAndView attendanceMonth(@ModelAttribute AttendanceInfo attendanceInfo,
    		ModelAndView mav) {
    	
    	Iterable<Attendance>attendanceinfo = t_attendance.findAll();
    	
    	
    	//Viewに返す変数をModelに収納
    	mav.addObject("attendanceinfo", attendanceinfo);
    	
    	//画面に出力するViewを指定
    	mav.setViewName("attendanceMonth");
    	//ModelとView情報を返す
    	return mav;
    	
    }
    
    
    
    //1日の勤怠登録
  
	@GetMapping("/login/attendance/month/daywork")
	public ModelAndView attendanceDaywork(@ModelAttribute AttendanceRegister attendanceRegister, ModelAndView mav) {
		
		//Viewに返す変数をModelに収納
		mav.addObject("AttendanceRegister", attendanceRegister);
		
		//画面に出力するViewを指定
		mav.setViewName("attendanceDaywork");
		//ModelとView情報を返す
		return mav;
		
	}
	
	
	
	/*
	 * 「"/login/attendance/month/daywork"」へPOST送信された場合
	 * */
    @PostMapping(value ="/login/attendance/month/daywork")
	//POSTデータをRegisterインスタンスとして受け入れる
	public ModelAndView attendanceDaywork(@ModelAttribute @Validated AttendanceRegister attendanceRegister,
			BindingResult result,ModelAndView mav) {
		//入力エラーがある場合
		if(result.hasErrors()) {
			//エラーメッセージ
			mav.addObject("message","入力内容に誤りがあります");
			
			//画面に出力するViewを指定
			mav.setViewName("attendanceDaywork");
			
			//ModelとView情報を返す
			return mav;
		}
		
		
		//入力されたデータをDBに保存
		t_attendance.saveAndFlush(attendanceRegister);
				
		//リダイレクト先を指定
		mav = new ModelAndView("redirect:/login/attendance/month");
		//フォワードの場合もやり方は同じです（“forward:○○”）。（○○は遷移先のURL）
		//ModelとView情報を返す
		return mav;
	}
		
    
    
    
    
    
    
    
    
    
    
    
    //管理者としての機能
    
    @GetMapping("/admin/list")
    public String showAdminList(Model model) {
    	
    	model.addAttribute("users",t_employee.findAll());
    	return "list";
    }
    
    
    
    @GetMapping("/admin/register")
    public String register(@ModelAttribute("user")Employee user) {
    		return "register";
			
		}
    
    @PostMapping("/admin/register")
    public String process(@Validated @ModelAttribute("user")Employee user,
    		BindingResult result) {
    	
    	if (result.hasErrors()) {
    		return "list";
			
		
    }
    
    	
    	user.setPassword(passwordEncoder.encode(user.getPassword()));//
    	if (user.isAdmin()) {
			user.setAuthority(Authority.ADMIN);
		}else {
			user.setAuthority(Authority.USER);
		}
    	t_employee.saveAndFlush(user);
    	
    	return "redirect:/admin/list";
    	
    	
    	
    }
    
}
