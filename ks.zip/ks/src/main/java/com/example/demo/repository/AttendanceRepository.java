package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.dao.AttendanceRegister;
import com.example.demo.entity.Attendance;


public interface AttendanceRepository extends JpaRepository<Attendance, String> {

	void saveAndFlush(AttendanceRegister attendanceRegister);


}
