package com.example.demo.entity;



import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.Data;


//勤怠登録するファイル
@Data
@Entity
@Table(name = "t_attendance")
public class Attendance {
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@ManyToOne
//	@JoinColumn(name = "EMPLOYEE_ID")//t_employeeのEMPLOYEE_ID
	private Long attendance_id;
	@Id
	private String  attendance_date;
	@NotBlank(message = "作業開始時間は必要です。")
	private String start_time;
	@NotBlank(message = "作業終了時間は必要です。")
	private String end_time;
	private String rest_hours;
	private String working_hours;
	private String overtime_hours;
	private String absence_hours;
	private String status_id;
	
	private String remarks;
	
	private String del_flg;
	private String comment;//管理者の備考
	
	private String create_user;
	private Date create_date;
	private Date update_date;
	private String update_user;
	
}
