package com.example.todolist.controller;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.todolist.entity.Todo;
import com.example.todolist.form.TodoData;
import com.example.todolist.repository.TodoRepository;
import com.example.todolist.service.TodoService;

import lombok.AllArgsConstructor;

@Controller
@AllArgsConstructor
public class TodoListController {
	private final TodoRepository todoRepository;
	private final TodoService todoService;
	
	private final HttpSession session;
	
	//Todo 一覧表示（Todolistで追加）
		@GetMapping("/todo")
		public ModelAndView showTodoList(ModelAndView mv) {
			
			//一覧を検索して表示する
			mv.setViewName("todoList");
			
			List<Todo>todoList=todoRepository.findAll();//SELECT*FROM todoに相当する
			
			mv.addObject("todoList",todoList);
			
			return mv;
		}
	
	
	@GetMapping("/todo/{id}")
	public ModelAndView todoById(@PathVariable(name ="id") int id, ModelAndView mv) {
		/*URIテンプレート変数idを@PathVariableで取得し、それを引数にfindById(でtodoテーブルを検索する)
		 * SELECT　*　FROM　todo WHERE　id = 引数idの値
		 * */
		
		
		mv.setViewName("todoForm");
		
		Todo todo = todoRepository.findById(id).get();
		
		mv.addObject("todoData",todo);
		
		session.setAttribute("mode", "update");
		
		return mv;
	}
	
	//ToDo入力フォーム表示
	//[処理1]ToDo一覧画面（todoList.html）で「新規追加」リンクがクリックされたとき
	@GetMapping("/todo/create")
	public ModelAndView createTodo(ModelAndView mv) {
		mv.setViewName("todoForm");
		mv.addObject("todoData", new TodoData());
		
		session.setAttribute("mode", "create");
		
		return mv;
	}
	
	
	//ToDo追加処理
	//[処理2]ToDo入力画面（todoForm.html）で「登録」ボタンがクリックされたとき
	@PostMapping("/todo/create")
	public String createTodo(@ModelAttribute @Validated TodoData todoData,
			BindingResult result,Model mv) {
		
		//エラーチェック
		boolean isValid = todoService.isValid(todoData,result);
		
		if (!result.hasErrors()&& isValid) {
			//エラーなし
			Todo todo = todoData.toEntity();
			todoRepository.saveAndFlush(todo);/*=INSERT INTO todo(title, importance,urgency,deadline,done)
			VALUES(画面に入力された件名,緊急度,期限,完了)*/
			
			return "redirect:/todo";
			
		} else {
			//エラーあり
			//mv.addObject("todoData",todoData)
			return "todoForm";

		}
		
	}
	



	//レコードを更新する
	@PostMapping("/todo/update")
	public String updateTodo(@ModelAttribute @Validated TodoData todoData,
			BindingResult result,Model model) {
		//エラーチェック
		boolean isValid = todoService.isValid(todoData, result);
		
		if (!result.hasErrors()&&isValid) {
			//エラーなし
			
			Todo todo = todoData.toEntity();
			
			todoRepository.saveAndFlush(todo);//UPDATE todo SET title = todo.title,...WHERE id = todo.id
			
			return "redirect:/todo";
			
		}else {
			
			//エラーあり
			//model.addAttribute("todoData",todoData);
			
			return "todoForm";
		
		}
		
	}
	//レコードを削除する
 	@PostMapping("/todo/delete")
 	public String deleteTodo(@ModelAttribute TodoData todoData) {
 		todoRepository.deleteById(todoData.getId());//DELETE FROM todoWHERE id = todoData.getId()の値
 		return "redirect:/todo";
 	}
 	
	
	//ToDo一覧へ戻る
	//[処理3]ToDo入力画面で「キャンセル登録」ボタンがクリックされたとき
	@PostMapping("/todo/cancel")
	public String cancel() {
		return "redirect:/todo";
	}

}
